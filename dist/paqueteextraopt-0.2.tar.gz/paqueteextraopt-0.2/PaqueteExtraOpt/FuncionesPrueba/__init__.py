from FuncionesMultivariables import rastrigin, ackley, himmelblau, sphere, rosenbrock,  beale, goldstein, booth, bunkin, matyas, levi, threehumpcamel,easom,crossintray, eggholder, holdertable, mccormick, schaffer2, schaffer_n4,  styblinskitang, shekel

from FuncionesUnivariables import f1, f2, f3, f4