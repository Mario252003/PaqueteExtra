from .randomwalked import caminata_aleatoria
from .cauchy import cauchy
from Reeves import fletcherReeves
from .HookeJeeves import hooke_jeeves
from .NelderMead import nelder_mead
from .newton import newton